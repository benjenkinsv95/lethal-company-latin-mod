# Lethal Company Latin Translation

This is an alpha mod for translating lethal company into latin.
