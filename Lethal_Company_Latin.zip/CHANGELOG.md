# Changelog

## Alpha 1.0.0
- Initial Broken Mod

## Alpha 1.0.2
- Chinese is removed and latin replaces it throughout. The terminal remains untranslated.